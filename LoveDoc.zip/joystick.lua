---
-- Provides an interface to the user's joystick.
--
-- @module joystick
--


return nil
